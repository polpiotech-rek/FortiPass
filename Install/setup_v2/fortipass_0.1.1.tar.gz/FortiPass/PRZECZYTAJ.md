<div align="center">
    <h1>🔐 Generator Haseł</h1>
</div>

**Aplikacja desktopowa** do generowania i zarządzania hasłami, stworzona z użyciem biblioteki **Tkinter**.
Pozwala na generowanie silnych haseł, ocenę ich siły, kopiowanie do schowka oraz przeglądanie logów systemowych.

---

<h2>✨ Funkcje</h2>

- 🔒 **Generowanie haseł:** Twórz silne hasła na podstawie wybranych kryteriów (długość, litery, cyfry, znaki specjalne).
- 🛡️ **Ocena siły hasła:** Zobacz, jak bezpieczne jest Twoje hasło dzięki wizualnym wskazówkom (kolor: zielony, pomarańczowy, czerwony).
- 📋 **Kopiowanie do schowka:** Wygodne kopiowanie haseł jednym kliknięciem.
- 🗒️ **Przeglądanie logów:** Przeglądaj logi systemowe w dedykowanym oknie z funkcją przewijania i ładowania wpisów.

---

<h2>⚙️ Wymagania</h2>

- 🐍 **Python:** wersja 3.x
- 📦 **Tkinter:** wbudowany w standardową bibliotekę Pythona
- 🛠️ **Dodatkowe moduły:**
  - `logging` (logowanie zdarzeń)
  - `string` (operacje na ciągach znaków)

---

<h2>🚀 Instalacja</h2>

1. Zainstaluj **Python 3.x**, jeśli nie masz go na swoim urządzeniu.
2. Pobierz pliki aplikacji na swój komputer.
3. Uruchom aplikację za pomocą poniższych poleceń:

   - **Windows:**
     ```bash
     python app.py
     ```

   - **Linux:**
     ```bash
     python3 app.py
     ```

---

<h2>🖱️ Jak używać</h2>

### 1. 🛠️ Generowanie hasła
- Wprowadź parametry, takie jak długość hasła i dodatkowe opcje (np. cyfry, znaki specjalne).
- Kliknij **"Generuj hasło"**, aby zobaczyć nowe hasło i jego ocenę.

### 2. 🔍 Ocena siły hasła
- Siła hasła jest oceniana na podstawie jego długości oraz użytych znaków.
- **Kolorowe oznaczenia:**
  - 🟢 Zielony – Silne hasło
  - 🟠 Pomarańczowy – Średnie hasło
  - 🔴 Czerwony – Słabe hasło

### 3. 📋 Kopiowanie do schowka
- Po wygenerowaniu hasła kliknij **"Kopiuj do schowka"**, aby szybko je skopiować.

### 4. 🗒️ Przeglądanie logów
- Kliknij **"Pokaż logi"**, aby otworzyć okno z listą działań zapisanych w logach (np. generowanie hasła, zamknięcie aplikacji).
- Logi można przewijać i ładować dodatkowe wpisy.

### 5. ❌ Zamykanie aplikacji
- Kliknij przycisk **"X"** w prawym górnym rogu.
- Pojawi się okno dialogowe z pytaniem o potwierdzenie. Wybierz **"Tak"** lub **"Nie"**.

---

<h2>📂 Logowanie</h2>

Aplikacja automatycznie zapisuje wszystkie istotne zdarzenia, takie jak:

- Wygenerowanie hasła.
- Skopiowanie hasła do schowka.
- Wyświetlenie logów.
- Próba zamknięcia aplikacji.

**Logi są zapisywane w pliku tekstowym i dostępne przez opcję "Pokaż logi".**

---

<h2>📄 Licencja</h2>

Ten projekt jest udostępniony na licencji **MIT**.
Możesz go swobodnie używać, modyfikować i rozpowszechniać, pod warunkiem zachowania informacji o licencji.

---

<div align="center">
    Wykonane z ❤️ przez [<b>Piotr Bodych</b>]
</div>
