from setuptools import setup, find_packages

setup(
    name="fortipass",
    version="0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        # Lista zależności, np.
        # 'requests',
    ],
    entry_points={
        'console_scripts': [
            'fortipass = fortipass.main:main',  # Jeśli masz funkcję main w src/fortipass/main.py
        ],
    },
)